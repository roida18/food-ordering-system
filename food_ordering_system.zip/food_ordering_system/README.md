# 🍔 FoodieHub - Modern Online Food Ordering System

A complete, production-ready food ordering website built with PHP, MySQL, HTML, CSS, and JavaScript. This project features a modern, responsive design with smooth animations and professional UI components.

![FoodieHub](https://img.shields.io/badge/FoodieHub-Food%20Ordering%20System-orange)
![PHP](https://img.shields.io/badge/PHP-7.4+-blue)
![MySQL](https://img.shields.io/badge/MySQL-Database-blue)
![License](https://img.shields.io/badge/License-Educational-green)

## ✨ Features

### Customer Features
- 🚀 **Modern UI/UX** - Beautiful, responsive design with smooth animations
- 📱 **Mobile Responsive** - Works perfectly on all devices
- 👤 **User Registration & Login** - Secure authentication system
- 🍔 **Browse Menu** - Category filtering with real-time search
- 🛒 **Shopping Cart** - Add, remove, update quantities
- 📦 **Order Placement** - Easy checkout process
- 💳 **Payment Options** - Cash on delivery supported
- 🔔 **Toast Notifications** - Real-time feedback for actions

### Admin Features
- 📊 **Dashboard** - Animated statistics with key metrics
- 📋 **Order Management** - View, filter, and update order status
- 🍔 **Menu Management** - Add, edit, delete food items
- 👥 **Customer Data** - Track customer orders
- 💰 **Revenue Tracking** - Monitor sales and revenue

## 🎨 Design Highlights

- **Modern Color Palette** - Warm orange primary with professional grays
- **Glassmorphism Effects** - Subtle blur effects on navigation
- **Smooth Animations** - Fade-ins, bounces, and transitions
- **Card-based Layout** - Clean, organized content presentation
- **Gradient Accents** - Modern gradient buttons and icons
- **Responsive Grid** - Adapts to all screen sizes

## 🛠️ Technology Stack

| Technology | Purpose |
|------------|---------|
| **HTML5** | Semantic markup structure |
| **CSS3** | Modern styling with variables, animations |
| **JavaScript (ES6+)** | Interactive features, API calls |
| **PHP 7.4+** | Server-side logic, authentication |
| **MySQL** | Database management |
| **XAMPP/WAMP** | Local development server |

## 📁 Project Structure

```
food-ordering-system/
├── admin/
│   ├── css/
│   │   └── admin.css          # Admin panel styles
│   ├── js/
│   │   └── admin.js           # Admin panel JavaScript
│   ├── dashboard.php          # Admin dashboard
│   ├── menu.php               # Menu management
│   └── orders.php             # Order management
│
├── api/
│   ├── admin_actions.php      # Admin API endpoints
│   ├── add_order.php          # Order placement
│   └── get_menu.php           # Menu retrieval
│
├── auth/
│   ├── admin_login.php        # Admin authentication
│   ├── login.php              # User login
│   ├── logout.php             # User logout
│   └── register.php           # User registration
│
├── config/
│   └── db.php                 # Database connection
│
├── css/
│   └── style.css              # Main stylesheet
│
├── database/
│   └── setup.sql              # Database schema & data
│
├── js/
│   └── main.js                # Main JavaScript file
│
├── index.html                 # Homepage
├── menu.php                   # Menu page
├── cart.html                  # Cart page
├── checkout.html              # Checkout page
└── README.md                  # Project documentation
```

## 🚀 Installation Guide

### Prerequisites
- XAMPP/WAMP server installed
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web browser (Chrome, Firefox, Edge)

### Step 1: Setup Database
1. Open **phpMyAdmin** (http://localhost/phpmyadmin)
2. Click **New** to create a database
3. Name: `food_ordering_system`
4. Select **utf8mb4_unicode_ci** collation
5. Click **Create**
6. Select the database
7. Go to **Import** tab
8. Choose `database/setup.sql` file
9. Click **Go** to import

### Step 2: Configure Project
1. Copy project folder to XAMPP htdocs: 
   ```
   C:\xampp\htdocs\food-ordering-system\
   ```
2. Verify database connection in `config/db.php`

### Step 3: Run the Project
1. Start Apache and MySQL in XAMPP Control Panel
2. Open browser and navigate to:
   ```
   http://localhost/food-ordering-system/
   ```

## 🔐 Login Credentials

### Admin Account
| Field | Value |
|-------|-------|
| Email | admin@foodiehub.com |
| Password | admin123 |

### Demo Customer Account
| Field | Value |
|-------|-------|
| Email | john@example.com |
| Password | user123 |

### Register New Account
Visit `auth/register.php` to create a new customer account.

## 📖 User Guide

### For Customers

1. **Browse Menu**
   - Visit the homepage
   - Click "Menu" to view all items
   - Use category filters (Burgers, Pizza, Asian, Drinks)
   - Click "Add to Cart" on desired items

2. **Manage Cart**
   - Click cart icon to view items
   - Adjust quantities using +/- buttons
   - Remove items with trash icon
   - View total price

3. **Place Order**
   - Click "Proceed to Checkout"
   - Enter delivery address
   - Select payment method
   - Click "Place Order"
   - Receive order confirmation

### For Admin

1. **Access Admin Panel**
   - Login with admin credentials
   - Click "Admin Panel" link or visit `admin/dashboard.php`

2. **Dashboard Overview**
   - View total orders, revenue, pending orders
   - See recent orders at a glance

3. **Manage Orders**
   - Go to "Orders" section
   - Filter by status (Pending, Processing, Completed)
   - View order details
   - Update order status

4. **Manage Menu**
   - Go to "Menu Management"
   - Add new food items
   - Edit existing items
   - Delete items
   - Toggle availability

## 📊 Database Schema

### Users Table
```sql
users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    role ENUM('admin', 'customer') DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
```

### Food Items Table
```sql
food_items (
    food_id INT PRIMARY KEY AUTO_INCREMENT,
    food_name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    category VARCHAR(50) DEFAULT 'burger',
    availability TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
```

### Orders Table
```sql
orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'processing', 'completed', 'cancelled'),
    delivery_address TEXT,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
)
```

### Order Details Table
```sql
order_details (
    order_detail_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    food_id INT NOT NULL,
    quantity INT DEFAULT 1,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (food_id) REFERENCES food_items(food_id)
)
```

### Payments Table
```sql
payments (
    payment_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    payment_method VARCHAR(50) DEFAULT 'cash_on_delivery',
    payment_status ENUM('pending', 'completed', 'failed'),
    amount DECIMAL(10,2) NOT NULL,
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(order_id)
)
```

## 🎯 Project Requirements Checklist

- [x] User Registration & Login
- [x] Role-based Access Control (Admin/Customer)
- [x] Menu Display with Categories
- [x] Shopping Cart Functionality
- [x] Order Placement System
- [x] Admin Dashboard
- [x] Order Management
- [x] Menu Management (CRUD)
- [x] Responsive Design
- [x] Input Validation
- [x] Secure Password Hashing
- [x] Database Normalization
- [x] Modern UI/UX
- [x] Smooth Animations
- [x] Toast Notifications
- [x] Loading States

## 🔮 Future Enhancements

- 💳 **Payment Gateway Integration** - PayPal, Stripe, Razorpay
- 📍 **Real-time Order Tracking** - GPS-based delivery tracking
- 📱 **Mobile App** - React Native or Flutter app
- ⭐ **Reviews & Ratings** - Customer feedback system
- 🎁 **Loyalty Program** - Points and rewards system
- 🏷️ **Discount Coupons** - Promotional codes
- 📧 **Email Notifications** - Order confirmations
- 🔍 **Advanced Search** - Filter by price, rating, etc.
- 🏪 **Multi-restaurant** - Support multiple restaurants

## 🧪 Testing

### Manual Testing Checklist
- [ ] User registration with validation
- [ ] User login/logout functionality
- [ ] Admin login with correct credentials
- [ ] Menu display and category filtering
- [ ] Add/remove items from cart
- [ ] Quantity updates in cart
- [ ] Order placement process
- [ ] Order status updates by admin
- [ ] Food item add/edit/delete
- [ ] Responsive design on mobile

## 📝 Documentation Sections (For Academic Report)

### 1. Introduction
- Project overview
- Problem statement
- Objectives
- Scope and limitations

### 2. System Analysis
- Feasibility study
- Requirements gathering
- Use case diagrams

### 3. System Design
- System architecture
- Database design (ER diagram)
- Data flow diagrams
- UI/UX design

### 4. Implementation
- Technology stack explanation
- Code snippets
- Function descriptions

### 5. Testing
- Test cases
- Test results
- Bug fixes

### 6. Conclusion
- Summary of work
- Lessons learned
- Future scope

## 🛡️ Security Features

- **Password Hashing** - Uses `password_hash()` with BCRYPT
- **SQL Injection Prevention** - Prepared statements
- **XSS Protection** - Input sanitization
- **Session Management** - Secure session handling
- **Input Validation** - Server-side validation

## 📈 Performance Optimizations

- CSS Variables for theming
- Minimized DOM operations
- Efficient database queries
- Lazy loading for images
- CSS animations over JavaScript where possible

## 🤝 Contributing

This is an academic project. For improvements or issues, please:
1. Fork the repository
2. Create a feature branch
3. Commit changes
4. Push to the branch
5. Open a Pull Request

## 📄 License

This project is created for educational purposes. Feel free to use and modify for learning.

## 👨‍💻 Developed By

**FoodieHub Development Team**

---

## 📞 Support

For questions or issues:
1. Check the README thoroughly
2. Verify XAMPP/Apache/MySQL are running
3. Check browser console for errors
4. Verify database import was successful

---

**Made with ❤️ and lots of pizza! 🍕**
