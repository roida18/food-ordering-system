<?php
require_once 'config/db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="FoodieHub - Browse our delicious menu">
    <title>Menu - FoodieHub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="navbar-inner">
            <a href="index.html" class="nav-brand">FoodieHub</a>
            
            <div class="nav-center">
                <a href="index.html" class="nav-link">Home</a>
                <a href="menu.php" class="nav-link active">Restaurants</a>
                <a href="about.html" class="nav-link">About</a>
                <a href="contact.html" class="nav-link">Contact</a>
            </div>
            
            <div class="nav-right">
                <div class="search-container">
                    <svg class="search-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="11" cy="11" r="8"></circle>
                        <path d="m21 21-4.35-4.35"></path>
                    </svg>
                    <input type="text" class="search-input" placeholder="Search dishes..." id="menu-search">
                </div>
                
                <?php if (is_logged_in()): ?>
                    <div class="user-menu">
                        <button class="user-button">
                            <div class="user-avatar"><?php echo substr($_SESSION['name'], 0, 2); ?></div>
                            <span class="user-name"><?php echo htmlspecialchars($_SESSION['name']); ?></span>
                        </button>
                    </div>
                <?php endif; ?>
                
                <button class="cart-button" onclick="toggleCart()">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="9" cy="21" r="1"></circle>
                        <circle cx="20" cy="21" r="1"></circle>
                        <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                    </svg>
                    <span class="cart-badge" id="cart-count">0</span>
                </button>
                
                <button class="mobile-menu-toggle hide-desktop">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="3" y1="12" x2="21" y2="12"></line>
                        <line x1="3" y1="6" x2="21" y2="6"></line>
                        <line x1="3" y1="18" x2="21" y2="18"></line>
                    </svg>
                </button>
            </div>
        </div>
    </nav>

    <!-- Menu Section -->
    <section class="menu-section">
        <div class="container">
            <div class="menu-header">
                <div class="section-title">
                    <span>Our Menu</span>
                    <h1>Fresh & Delicious</h1>
                </div>
                <div class="menu-tabs">
                    <button class="menu-tab active" data-category="all">All</button>
                    <button class="menu-tab" data-category="burger">Burgers</button>
                    <button class="menu-tab" data-category="pizza">Pizza</button>
                    <button class="menu-tab" data-category="asian">Asian</button>
                    <button class="menu-tab" data-category="drink">Drinks</button>
                    <button class="menu-tab" data-category="dessert">Desserts</button>
                </div>
            </div>
            
            <div class="menu-grid" id="menu-container">
                <!-- Menu items will be loaded here -->
            </div>
            
            <div id="no-results" class="cart-empty" style="display: none;">
                <div class="empty-icon">🔍</div>
                <h3>No items found</h3>
                <p>Try adjusting your search or filter</p>
            </div>
        </div>
    </section>

    <!-- Cart Sidebar -->
    <div class="cart-overlay" onclick="toggleCart()"></div>
    <div class="cart-sidebar">
        <div class="cart-header">
            <h2>Your cart</h2>
            <button class="cart-close" onclick="toggleCart()">×</button>
        </div>
        <div class="cart-items" id="cart-items">
            <!-- Cart items will be loaded here -->
        </div>
        <div class="cart-footer">
            <div class="cart-summary">
                <div class="cart-summary-row">
                    <span>Subtotal</span>
                    <span id="cart-subtotal">$0.00</span>
                </div>
                <div class="cart-summary-row">
                    <span>Delivery fee</span>
                    <span>$2.00</span>
                </div>
                <div class="cart-summary-row total">
                    <span>Total</span>
                    <span id="cart-total">$2.00</span>
                </div>
            </div>
            <?php if (is_logged_in()): ?>
                <a href="checkout.html" class="btn btn-primary btn-block">Checkout</a>
            <?php else: ?>
                <a href="auth/login.php" class="btn btn-primary btn-block">Login to order</a>
            <?php endif; ?>
            <a href="menu.php" class="btn btn-ghost btn-block" style="margin-top: 0.5rem;">Continue Shopping</a>
        </div>
    </div>

    <!-- Floating Cart Button (Mobile) -->
    <button class="cart-fab" onclick="toggleCart()">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="9" cy="21" r="1"></circle>
            <circle cx="20" cy="21" r="1"></circle>
            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
        </svg>
        <span>View Cart</span>
        <span class="cart-badge" id="cart-fab-count">0</span>
    </button>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-bottom" style="justify-content: center;">
                <p>&copy; 2024 FoodieHub. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="js/main.js"></script>
    <script>
        let allMenuItems = [];
        let currentFilter = 'all';

        document.addEventListener('DOMContentLoaded', async function() {
            await loadMenu();
            setupFilters();
            setupSearch();
        });

        async function loadMenu() {
            try {
                const response = await fetch('api/get_menu.php');
                const data = await response.json();

                if (data.success) {
                    allMenuItems = data.data;
                    renderMenu(allMenuItems);
                }
            } catch (error) {
                console.error('Error loading menu:', error);
                showToast('Error loading menu', 'error');
            }
        }

        function renderMenu(items) {
            const container = document.getElementById('menu-container');
            const noResults = document.getElementById('no-results');
            
            if (!container) return;

            if (items.length === 0) {
                container.innerHTML = '';
                noResults.style.display = 'block';
                return;
            }

            noResults.style.display = 'none';
            container.innerHTML = items.map(item => `
                <div class="menu-card" data-category="${item.category}" data-name="${item.food_name.toLowerCase()}">
                    <div class="menu-card-image">
                        <span style="font-size: 4rem;">${getFoodEmoji(item.category)}</span>
                    </div>
                    <button class="menu-card-favorite" onclick="toggleFavorite(${item.food_id})">♡</button>
                    ${item.availability != 1 ? '<span class="menu-card-badge">Unavailable</span>' : ''}
                    <div class="menu-card-content">
                        <div class="menu-card-header">
                            <h3 class="menu-card-title">${item.food_name}</h3>
                            <div class="menu-card-rating">
                                <svg viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                                <span>4.8</span>
                            </div>
                        </div>
                        <p class="menu-card-description">${item.description}</p>
                        <div class="menu-card-footer">
                            <div class="menu-card-price">
                                <span class="price">$${parseFloat(item.price).toFixed(2)}</span>
                                <span class="delivery">15-25 min</span>
                            </div>
                            ${item.availability == 1 ? `
                            <button class="add-button" onclick="addToCart(${item.food_id}, '${item.food_name.replace(/'/g, "\\'")}', ${item.price})">
                                <span>+</span> Add
                            </button>
                            ` : ''}
                        </div>
                    </div>
                </div>
            `).join('');
        }

        function setupFilters() {
            const filterButtons = document.querySelectorAll('.menu-tab');
            
            filterButtons.forEach(btn => {
                btn.addEventListener('click', () => {
                    filterButtons.forEach(b => b.classList.remove('active'));
                    btn.classList.add('active');
                    
                    currentFilter = btn.dataset.category;
                    filterItems();
                });
            });
        }

        function setupSearch() {
            const searchInput = document.getElementById('menu-search');
            if (searchInput) {
                searchInput.addEventListener('input', filterItems);
            }
        }

        function filterItems() {
            const searchTerm = document.getElementById('menu-search')?.value.toLowerCase() || '';
            
            let filtered = allMenuItems;
            
            // Filter by category
            if (currentFilter !== 'all') {
                filtered = filtered.filter(item => item.category === currentFilter);
            }
            
            // Filter by search term
            if (searchTerm) {
                filtered = filtered.filter(item => 
                    item.food_name.toLowerCase().includes(searchTerm) ||
                    item.description.toLowerCase().includes(searchTerm)
                );
            }
            
            renderMenu(filtered);
        }

        function getFoodEmoji(category) {
            const emojis = {
                'burger': '🍔',
                'pizza': '🍕',
                'asian': '🍜',
                'drink': '🥤',
                'dessert': '🍰'
            };
            return emojis[category] || '🍽️';
        }

        function toggleFavorite(foodId) {
            showToast('Added to favorites!', 'success');
        }

        // Override cart display functions for menu page
        function updateCartDisplay() {
            const cartCount = getCartCount();
            document.getElementById('cart-count').textContent = cartCount;
            document.getElementById('cart-fab-count').textContent = cartCount;
            
            // Update cart sidebar
            renderCartSidebar();
            
            // Update totals
            const subtotal = getCartTotal();
            document.getElementById('cart-subtotal').textContent = '$' + subtotal.toFixed(2);
            document.getElementById('cart-total').textContent = '$' + (subtotal + 2).toFixed(2);
        }

        function renderCartSidebar() {
            const cartItemsContainer = document.getElementById('cart-items');
            if (!cartItemsContainer) return;

            if (cart.length === 0) {
                cartItemsContainer.innerHTML = `
                    <div class="cart-empty">
                        <div class="cart-empty-icon">🛒</div>
                        <h3>Your cart is empty</h3>
                        <p>Add delicious items to get started!</p>
                    </div>
                `;
                return;
            }

            cartItemsContainer.innerHTML = cart.map(item => `
                <div class="cart-item" data-food-id="${item.food_id}">
                    <div class="cart-item-image">${getFoodEmoji(item.category || 'burger')}</div>
                    <div class="cart-item-details">
                        <span class="cart-item-name">${item.food_name}</span>
                        <span class="cart-item-price">$${item.price.toFixed(2)}</span>
                        <div class="cart-item-actions">
                            <div class="quantity-selector">
                                <button class="quantity-btn" onclick="updateQuantity(${item.food_id}, -1)">−</button>
                                <span class="quantity-value">${item.quantity}</span>
                                <button class="quantity-btn" onclick="updateQuantity(${item.food_id}, 1)">+</button>
                            </div>
                            <button class="cart-item-remove" onclick="removeFromCart(${item.food_id})">🗑️</button>
                        </div>
                    </div>
                </div>
            `).join('');
        }
    </script>
</body>
</html>
