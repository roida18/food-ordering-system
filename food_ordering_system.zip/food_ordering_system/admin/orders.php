<?php
require_once '../config/db.php';

// Check if admin is logged in
if (!is_logged_in() || !is_admin()) {
    redirect('../auth/login.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders Management - FoodieHub</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <div class="admin-layout">
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <h2>Admin Panel</h2>
            </div>
            <nav class="sidebar-nav">
                <a href="dashboard.php">📊 Dashboard</a>
                <a href="orders.php" class="active">📋 Orders</a>
                <a href="menu.php">🍔 Menu Management</a>
                <a href="../index.html">View Website</a>
                <a href="../auth/logout.php" class="logout">🚪 Logout</a>
            </nav>
        </aside>
        
        <main class="admin-main">
            <header class="admin-header">
                <h1>Orders Management</h1>
            </header>
            
            <div class="admin-content">
                <div class="filter-bar">
                    <button class="filter-btn active" data-status="all">All Orders</button>
                    <button class="filter-btn" data-status="pending">Pending</button>
                    <button class="filter-btn" data-status="processing">Processing</button>
                    <button class="filter-btn" data-status="completed">Completed</button>
                    <button class="filter-btn" data-status="cancelled">Cancelled</button>
                </div>
                
                <div class="orders-table-container">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Customer</th>
                                <th>Items</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="orders-table-body">
                            <!-- Orders will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <div id="order-details-modal" class="modal">
        <div class="modal-content modal-lg">
            <div class="modal-header">
                <h2>Order Details</h2>
                <button class="close-modal" onclick="closeOrderDetails()">&times;</button>
            </div>
            <div id="order-details-content">
                <!-- Order details will be loaded here -->
            </div>
        </div>
    </div>

    <script src="../js/main.js"></script>
    <script src="js/admin.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            loadOrders('all');
            setupOrderFilters();
        });
    </script>
</body>
</html>
