/**
 * Admin Panel - Modern Food Ordering System
 * Admin JavaScript File
 */

// ============================================
// Dashboard Functions
// ============================================

async function loadDashboardStats() {
    try {
        const response = await fetch('../api/admin_actions.php?action=get_stats');
        const data = await response.json();

        if (data.success) {
            animateValue('total-orders', 0, data.data.total_orders, 1000);
            animateValue('total-revenue', 0, data.data.total_revenue, 1000, '$');
            animateValue('pending-orders', 0, data.data.pending_orders, 1000);
            animateValue('total-customers', 0, data.data.total_customers, 1000);
        }
    } catch (error) {
        console.error('Error loading stats:', error);
        showToast('Error loading statistics', 'error');
    }
}

// Animate number values
function animateValue(elementId, start, end, duration, prefix = '') {
    const element = document.getElementById(elementId);
    if (!element) return;

    const startTime = performance.now();
    const isFloat = typeof end === 'number' && !Number.isInteger(end);

    function update(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        // Easing function
        const easeOutQuart = 1 - Math.pow(1 - progress, 4);
        
        const current = start + (end - start) * easeOutQuart;
        
        if (isFloat) {
            element.textContent = prefix + current.toFixed(2);
        } else {
            element.textContent = prefix + Math.floor(current);
        }

        if (progress < 1) {
            requestAnimationFrame(update);
        }
    }

    requestAnimationFrame(update);
}

async function loadRecentOrders() {
    try {
        const response = await fetch('../api/admin_actions.php?action=get_orders');
        const data = await response.json();

        if (data.success) {
            renderRecentOrders(data.data.slice(0, 5));
        }
    } catch (error) {
        console.error('Error loading orders:', error);
        showToast('Error loading orders', 'error');
    }
}

function renderRecentOrders(orders) {
    const container = document.getElementById('recent-orders');

    if (!container) return;

    if (orders.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">📋</div>
                <h3>No orders yet</h3>
                <p>Orders will appear here once customers start placing them</p>
            </div>
        `;
        return;
    }

    container.innerHTML = orders.map(order => `
        <div class="recent-order-item" onclick="viewOrderDetails(${order.order_id})" style="cursor: pointer;">
            <div class="order-info">
                <h4>Order #${order.order_id}</h4>
                <p>${escapeHtml(order.customer_name)} - ${formatDate(order.order_date)}</p>
            </div>
            <div style="display: flex; align-items: center; gap: 1rem;">
                <span class="status-badge status-${order.status}">${capitalizeFirst(order.status)}</span>
                <span class="order-amount">$${parseFloat(order.total_amount).toFixed(2)}</span>
            </div>
        </div>
    `).join('');
}

// ============================================
// Orders Management
// ============================================

async function loadOrders(status = 'all') {
    try {
        showLoading(true);
        const response = await fetch(`../api/admin_actions.php?action=get_orders&status=${status}`);
        const data = await response.json();

        if (data.success) {
            renderOrdersTable(data.data);
        }
    } catch (error) {
        console.error('Error loading orders:', error);
        showToast('Error loading orders', 'error');
    } finally {
        showLoading(false);
    }
}

function renderOrdersTable(orders) {
    const tbody = document.getElementById('orders-table-body');

    if (!tbody) return;

    if (orders.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" style="text-align: center; padding: 3rem;">
                    <div class="empty-state-icon">📦</div>
                    <h3>No orders found</h3>
                    <p>No orders match the selected filter</p>
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = orders.map(order => `
        <tr>
            <td><strong>#${order.order_id}</strong></td>
            <td>
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <div class="admin-user-avatar" style="width: 32px; height: 32px; font-size: 0.8rem;">
                        ${getInitials(order.customer_name)}
                    </div>
                    <div>
                        <div style="font-weight: 500;">${escapeHtml(order.customer_name)}</div>
                        <div style="font-size: 0.85rem; color: var(--text-muted);">${order.phone}</div>
                    </div>
                </div>
            </td>
            <td>${order.items.length} item${order.items.length > 1 ? 's' : ''}</td>
            <td><strong>$${parseFloat(order.total_amount).toFixed(2)}</strong></td>
            <td><span class="status-badge status-${order.status}">${capitalizeFirst(order.status)}</span></td>
            <td>${formatDate(order.order_date)}</td>
            <td class="actions">
                <button class="btn btn-primary btn-sm" onclick="viewOrderDetails(${order.order_id})">
                    View
                </button>
            </td>
        </tr>
    `).join('');
}

function setupOrderFilters() {
    const filterButtons = document.querySelectorAll('.filter-bar .filter-btn');

    filterButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            filterButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            loadOrders(btn.dataset.status);
        });
    });
}

async function viewOrderDetails(orderId) {
    try {
        showLoading(true);
        const response = await fetch(`../api/admin_actions.php?action=get_orders`);
        const data = await response.json();

        if (data.success) {
            const order = data.data.find(o => o.order_id === orderId);

            if (order) {
                renderOrderDetails(order);
                document.getElementById('order-details-modal').classList.add('open');
            }
        }
    } catch (error) {
        console.error('Error loading order details:', error);
        showToast('Error loading order details', 'error');
    } finally {
        showLoading(false);
    }
}

function renderOrderDetails(order) {
    const container = document.getElementById('order-details-content');

    if (!container) return;

    container.innerHTML = `
        <div class="order-details-header">
            <div class="order-details-info">
                <h3>Order #${order.order_id}</h3>
                <p><strong>Customer:</strong> ${escapeHtml(order.customer_name)}</p>
                <p><strong>Email:</strong> ${order.email}</p>
                <p><strong>Phone:</strong> ${order.phone}</p>
                <p><strong>Date:</strong> ${formatDateTime(order.order_date)}</p>
            </div>
            <select class="order-status-select" onchange="updateOrderStatus(${order.order_id}, this.value)">
                <option value="pending" ${order.status === 'pending' ? 'selected' : ''}>Pending</option>
                <option value="processing" ${order.status === 'processing' ? 'selected' : ''}>Processing</option>
                <option value="completed" ${order.status === 'completed' ? 'selected' : ''}>Completed</option>
                <option value="cancelled" ${order.status === 'cancelled' ? 'selected' : ''}>Cancelled</option>
            </select>
        </div>

        <div class="order-details-items">
            <h4>Order Items:</h4>
            ${order.items.map(item => `
                <div class="order-detail-item">
                    <span>${escapeHtml(item.food_name)} × ${item.quantity}</span>
                    <span>$${(item.price * item.quantity).toFixed(2)}</span>
                </div>
            `).join('')}
        </div>

        <div class="order-details-total">
            <div class="total-row">
                <span>Subtotal:</span>
                <span>$${parseFloat(order.total_amount).toFixed(2)}</span>
            </div>
            <div class="total-row">
                <span>Delivery:</span>
                <span>$2.00</span>
            </div>
            <div class="total-row grand-total">
                <span>Total:</span>
                <span>$${(parseFloat(order.total_amount) + 2).toFixed(2)}</span>
            </div>
        </div>

        <div style="margin-top: 1.5rem; padding: 1.25rem; background: var(--gray-50); border-radius: var(--radius-lg);">
            <h4 style="margin-bottom: 0.75rem;">Delivery Address:</h4>
            <p style="color: var(--text-secondary);">${escapeHtml(order.delivery_address || 'Not provided')}</p>
        </div>
    `;
}

async function updateOrderStatus(orderId, status) {
    try {
        const formData = new FormData();
        formData.append('order_id', orderId);
        formData.append('status', status);

        showLoading(true);
        const response = await fetch('../api/admin_actions.php?action=update_order_status', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();

        if (data.success) {
            showToast('Order status updated successfully!', 'success');
            // Refresh orders list
            const activeFilter = document.querySelector('.filter-bar .filter-btn.active');
            loadOrders(activeFilter?.dataset.status || 'all');
        } else {
            showToast(data.message || 'Failed to update status', 'error');
        }
    } catch (error) {
        console.error('Error updating order status:', error);
        showToast('Error updating order status', 'error');
    } finally {
        showLoading(false);
    }
}

function closeOrderDetails() {
    document.getElementById('order-details-modal').classList.remove('open');
}

// ============================================
// Menu Management
// ============================================

async function loadAdminMenu() {
    try {
        showLoading(true);
        const response = await fetch('../api/get_menu.php');
        const data = await response.json();

        if (data.success) {
            renderAdminMenu(data.data);
        }
    } catch (error) {
        console.error('Error loading menu:', error);
        showToast('Error loading menu', 'error');
    } finally {
        showLoading(false);
    }
}

function renderAdminMenu(items) {
    const container = document.getElementById('admin-menu-grid');

    if (!container) return;

    if (items.length === 0) {
        container.innerHTML = `
            <div class="empty-state" style="grid-column: 1 / -1;">
                <div class="empty-state-icon">🍽️</div>
                <h3>No menu items yet</h3>
                <p>Add your first food item to get started</p>
                <button class="btn btn-primary" onclick="openFoodModal()">+ Add Food Item</button>
            </div>
        `;
        return;
    }

    container.innerHTML = items.map(item => `
        <div class="admin-menu-item" data-food-id="${item.food_id}">
            <div class="admin-menu-item-image">${getFoodEmoji(item.category)}</div>
            <div class="admin-menu-item-content">
                <h3>${escapeHtml(item.food_name)}</h3>
                <p>${escapeHtml(item.description)}</p>
                <div class="admin-menu-item-footer">
                    <span class="price">$${parseFloat(item.price).toFixed(2)}</span>
                    <div class="admin-menu-item-actions">
                        <button class="btn btn-outline btn-sm" onclick="editFoodItem(${item.food_id})">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="deleteFoodItem(${item.food_id})">Delete</button>
                    </div>
                </div>
                <div style="margin-top: 0.75rem;">
                    <span class="status-badge ${item.availability == 1 ? 'status-completed' : 'status-cancelled'}">
                        ${item.availability == 1 ? 'Available' : 'Unavailable'}
                    </span>
                </div>
            </div>
        </div>
    `).join('');
}

function getFoodEmoji(category) {
    const emojis = {
        'burger': '🍔',
        'pizza': '🍕',
        'asian': '🍜',
        'drink': '🥤',
        'dessert': '🍰'
    };
    return emojis[category] || '🍽️';
}

function openFoodModal() {
    document.getElementById('food-modal-title').textContent = 'Add New Food Item';
    document.getElementById('food-form').reset();
    document.getElementById('food_id').value = '';
    document.getElementById('food-modal').classList.add('open');
}

function closeFoodModal() {
    document.getElementById('food-modal').classList.remove('open');
}

async function editFoodItem(foodId) {
    try {
        showLoading(true);
        const response = await fetch(`../api/admin_actions.php?action=get_food&food_id=${foodId}`);
        const data = await response.json();

        if (data.success) {
            const item = data.data;
            document.getElementById('food-modal-title').textContent = 'Edit Food Item';
            document.getElementById('food_id').value = item.food_id;
            document.getElementById('food_name').value = item.food_name;
            document.getElementById('description').value = item.description;
            document.getElementById('price').value = item.price;
            document.getElementById('category').value = item.category;
            document.getElementById('availability').checked = item.availability == 1;
            document.getElementById('food-modal').classList.add('open');
        }
    } catch (error) {
        console.error('Error loading food item:', error);
        showToast('Error loading food item', 'error');
    } finally {
        showLoading(false);
    }
}

async function saveFoodItem(event) {
    event.preventDefault();

    const foodId = document.getElementById('food_id').value;
    const formData = new FormData();
    formData.append('food_name', document.getElementById('food_name').value);
    formData.append('description', document.getElementById('description').value);
    formData.append('price', document.getElementById('price').value);
    formData.append('category', document.getElementById('category').value);
    formData.append('availability', document.getElementById('availability').checked ? 1 : 0);

    if (foodId) {
        formData.append('food_id', foodId);
        formData.append('action', 'update_food');
    } else {
        formData.append('action', 'add_food');
    }

    try {
        showLoading(true);
        const url = foodId 
            ? `../api/admin_actions.php?action=update_food`
            : `../api/admin_actions.php?action=add_food`;
        const response = await fetch(url, {
            method: 'POST',
            body: formData
        });

        const data = await response.json();

        if (data.success) {
            showToast(foodId ? 'Food item updated successfully!' : 'Food item added successfully!', 'success');
            closeFoodModal();
            loadAdminMenu();
        } else {
            showToast(data.message || 'Failed to save food item', 'error');
        }
    } catch (error) {
        console.error('Error saving food item:', error);
        showToast('Error saving food item', 'error');
    } finally {
        showLoading(false);
    }
}

async function deleteFoodItem(foodId) {
    const item = document.querySelector(`.admin-menu-item[data-food-id="${foodId}"]`);
    const itemName = item?.querySelector('h3')?.textContent || 'this item';

    if (!confirm(`Are you sure you want to delete "${itemName}"?`)) {
        return;
    }

    try {
        showLoading(true);
        const response = await fetch(`../api/admin_actions.php?action=delete_food&food_id=${foodId}`);
        const data = await response.json();

        if (data.success) {
            showToast('Food item deleted successfully!', 'success');
            loadAdminMenu();
        } else {
            showToast(data.message || 'Failed to delete food item', 'error');
        }
    } catch (error) {
        console.error('Error deleting food item:', error);
        showToast('Error deleting food item', 'error');
    } finally {
        showLoading(false);
    }
}

// ============================================
// Toast Notifications
// ============================================

function showToast(message, type = 'success') {
    const existingToast = document.querySelector('.toast-container');
    if (existingToast) {
        existingToast.remove();
    }

    const container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    const icons = {
        success: '✓',
        error: '✕',
        info: 'ℹ'
    };
    
    toast.innerHTML = `
        <span style="margin-right: 0.5rem;">${icons[type]}</span>
        <span>${escapeHtml(message)}</span>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.style.animation = 'slideOutRight 0.3s ease forwards';
        setTimeout(() => {
            toast.remove();
            if (container.children.length === 0) {
                container.remove();
            }
        }, 300);
    }, 3000);
}

// ============================================
// Loading States
// ============================================

function showLoading(show) {
    let loader = document.querySelector('.loading-overlay');
    
    if (show) {
        if (!loader) {
            loader = document.createElement('div');
            loader.className = 'loading-overlay';
            loader.innerHTML = '<div class="loading-spinner"></div>';
            document.body.appendChild(loader);
        }
        loader.style.display = 'flex';
    } else {
        if (loader) {
            loader.style.display = 'none';
        }
    }
}

// ============================================
// Utility Functions
// ============================================

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function capitalizeFirst(str) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
    });
}

function formatDateTime(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function getInitials(name) {
    if (!name) return '?';
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
}

// ============================================
// Modal Event Handlers
// ============================================

document.addEventListener('click', function(event) {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        if (event.target === modal) {
            modal.classList.remove('open');
        }
    });
});

document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        const openModals = document.querySelectorAll('.modal.open');
        openModals.forEach(modal => {
            modal.classList.remove('open');
        });
    }
});

// ============================================
// Initialize
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    // Add animation observer
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, { threshold: 0.1 });

    document.querySelectorAll('.stat-card, .admin-menu-item, .recent-order-item').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        observer.observe(el);
    });
});

// Export functions
window.loadDashboardStats = loadDashboardStats;
window.loadRecentOrders = loadRecentOrders;
window.loadOrders = loadOrders;
window.viewOrderDetails = viewOrderDetails;
window.updateOrderStatus = updateOrderStatus;
window.closeOrderDetails = closeOrderDetails;
window.loadAdminMenu = loadAdminMenu;
window.openFoodModal = openFoodModal;
window.closeFoodModal = closeFoodModal;
window.editFoodItem = editFoodItem;
window.saveFoodItem = saveFoodItem;
window.deleteFoodItem = deleteFoodItem;
window.showToast = showToast;
