<?php
require_once '../config/db.php';

// Check if admin is logged in
if (!is_logged_in() || !is_admin()) {
    redirect('../auth/login.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - FoodieHub</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <div class="admin-layout">
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <h2>Admin Panel</h2>
            </div>
            <nav class="sidebar-nav">
                <a href="dashboard.php" class="active">📊 Dashboard</a>
                <a href="orders.php">📋 Orders</a>
                <a href="menu.php">🍔 Menu Management</a>
                <a href="../index.html">View Website</a>
                <a href="../auth/logout.php" class="logout">🚪 Logout</a>
            </nav>
        </aside>
        
        <main class="admin-main">
            <header class="admin-header">
                <h1>Dashboard</h1>
                <span class="admin-user">Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?></span>
            </header>
            
            <div class="admin-content">
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon">📦</div>
                        <div class="stat-info">
                            <h3 id="total-orders">0</h3>
                            <p>Total Orders</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">💰</div>
                        <div class="stat-info">
                            <h3 id="total-revenue">$0</h3>
                            <p>Total Revenue</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">⏳</div>
                        <div class="stat-info">
                            <h3 id="pending-orders">0</h3>
                            <p>Pending Orders</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">👥</div>
                        <div class="stat-info">
                            <h3 id="total-customers">0</h3>
                            <p>Total Customers</p>
                        </div>
                    </div>
                </div>
                
                <div class="dashboard-sections">
                    <div class="dashboard-section">
                        <h2>Recent Orders</h2>
                        <div id="recent-orders" class="recent-orders">
                            <!-- Recent orders will be loaded here -->
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="../js/main.js"></script>
    <script src="js/admin.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            loadDashboardStats();
            loadRecentOrders();
        });
    </script>
</body>
</html>
