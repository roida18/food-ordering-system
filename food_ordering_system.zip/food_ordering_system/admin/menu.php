<?php
require_once '../config/db.php';

// Check if admin is logged in
if (!is_logged_in() || !is_admin()) {
    redirect('../auth/login.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Management - FoodieHub</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <div class="admin-layout">
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <h2>Admin Panel</h2>
            </div>
            <nav class="sidebar-nav">
                <a href="dashboard.php">📊 Dashboard</a>
                <a href="orders.php">📋 Orders</a>
                <a href="menu.php" class="active">🍔 Menu Management</a>
                <a href="../index.html">View Website</a>
                <a href="../auth/logout.php" class="logout">🚪 Logout</a>
            </nav>
        </aside>
        
        <main class="admin-main">
            <header class="admin-header">
                <h1>Menu Management</h1>
                <button class="btn btn-primary" onclick="openFoodModal()">+ Add New Item</button>
            </header>
            
            <div class="admin-content">
                <div class="menu-grid" id="admin-menu-grid">
                    <!-- Menu items will be loaded here -->
                </div>
            </div>
        </main>
    </div>

    <div id="food-modal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="food-modal-title">Add New Food Item</h2>
                <button class="close-modal" onclick="closeFoodModal()">&times;</button>
            </div>
            <form id="food-form" onsubmit="saveFoodItem(event)">
                <input type="hidden" id="food_id" name="food_id">
                
                <div class="form-group">
                    <label for="food_name">Food Name</label>
                    <input type="text" id="food_name" name="food_name" required>
                </div>
                
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" required></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="price">Price ($)</label>
                        <input type="number" id="price" name="price" step="0.01" min="0" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="category">Category</label>
                        <select id="category" name="category" required>
                            <option value="burger">Burgers</option>
                            <option value="pizza">Pizza</option>
                            <option value="asian">Asian</option>
                            <option value="drink">Drinks</option>
                            <option value="dessert">Desserts</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" id="availability" name="availability" checked>
                        <span>Available for ordering</span>
                    </label>
                </div>
                
                <div class="form-actions">
                    <button type="button" class="btn btn-outline" onclick="closeFoodModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Food Item</button>
                </div>
            </form>
        </div>
    </div>

    <script src="../js/main.js"></script>
    <script src="js/admin.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            loadAdminMenu();
        });
    </script>
</body>
</html>
