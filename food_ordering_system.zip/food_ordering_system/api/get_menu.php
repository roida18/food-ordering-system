<?php
require_once '../config/db.php';

header('Content-Type: application/json');

// Get all food items
$sql = "SELECT * FROM food_items WHERE availability = 1 ORDER BY category, food_name";
$result = $conn->query($sql);

$food_items = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $food_items[] = $row;
    }
}

echo json_encode([
    'success' => true,
    'data' => $food_items
]);
