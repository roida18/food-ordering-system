<?php
require_once '../../config/db.php';

// Check if admin is logged in
if (!is_logged_in() || !is_admin()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'get_orders':
        get_orders();
        break;
    case 'update_order_status':
        update_order_status();
        break;
    case 'add_food':
        add_food();
        break;
    case 'update_food':
        update_food();
        break;
    case 'delete_food':
        delete_food();
        break;
    case 'get_food':
        get_food();
        break;
    case 'get_stats':
        get_stats();
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}

function get_orders() {
    global $conn;
    
    $status_filter = $_GET['status'] ?? 'all';
    
    $sql = "SELECT o.*, u.name as customer_name, u.phone, u.email 
            FROM orders o 
            JOIN users u ON o.user_id = u.user_id";
    
    if ($status_filter !== 'all') {
        $sql .= " WHERE o.status = '" . sanitize_input($status_filter) . "'";
    }
    
    $sql .= " ORDER BY o.order_date DESC";
    
    $result = $conn->query($sql);
    $orders = [];
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Get order details
            $details_sql = "SELECT od.*, f.food_name FROM order_details od 
                           JOIN food_items f ON od.food_id = f.food_id 
                           WHERE od.order_id = " . $row['order_id'];
            $details_result = $conn->query($details_sql);
            $row['items'] = [];
            
            if ($details_result->num_rows > 0) {
                while ($detail = $details_result->fetch_assoc()) {
                    $row['items'][] = $detail;
                }
            }
            
            $orders[] = $row;
        }
    }
    
    echo json_encode(['success' => true, 'data' => $orders]);
}

function update_order_status() {
    global $conn;
    
    $order_id = intval($_POST['order_id']);
    $status = sanitize_input($_POST['status']);
    
    $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
    $stmt->bind_param("si", $status, $order_id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Order status updated']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update status']);
    }
}

function add_food() {
    global $conn;
    
    $food_name = sanitize_input($_POST['food_name']);
    $description = sanitize_input($_POST['description']);
    $price = floatval($_POST['price']);
    $category = sanitize_input($_POST['category']);
    $availability = isset($_POST['availability']) ? 1 : 0;
    
    $stmt = $conn->prepare("INSERT INTO food_items (food_name, description, price, category, availability) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdsi", $food_name, $description, $price, $category, $availability);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Food item added']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to add food item']);
    }
}

function update_food() {
    global $conn;
    
    $food_id = intval($_POST['food_id']);
    $food_name = sanitize_input($_POST['food_name']);
    $description = sanitize_input($_POST['description']);
    $price = floatval($_POST['price']);
    $category = sanitize_input($_POST['category']);
    $availability = isset($_POST['availability']) ? 1 : 0;
    
    $stmt = $conn->prepare("UPDATE food_items SET food_name = ?, description = ?, price = ?, category = ?, availability = ? WHERE food_id = ?");
    $stmt->bind_param("ssdsii", $food_name, $description, $price, $category, $availability, $food_id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Food item updated']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update food item']);
    }
}

function delete_food() {
    global $conn;
    
    $food_id = intval($_GET['food_id']);
    
    $stmt = $conn->prepare("DELETE FROM food_items WHERE food_id = ?");
    $stmt->bind_param("i", $food_id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Food item deleted']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to delete food item']);
    }
}

function get_food() {
    global $conn;
    
    $food_id = intval($_GET['food_id']);
    
    $stmt = $conn->prepare("SELECT * FROM food_items WHERE food_id = ?");
    $stmt->bind_param("i", $food_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        echo json_encode(['success' => true, 'data' => $result->fetch_assoc()]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Food item not found']);
    }
}

function get_stats() {
    global $conn;
    
    // Total orders
    $result = $conn->query("SELECT COUNT(*) as total FROM orders");
    $total_orders = $result->fetch_assoc()['total'];
    
    // Total revenue
    $result = $conn->query("SELECT SUM(total_amount) as total FROM orders WHERE status = 'completed'");
    $total_revenue = $result->fetch_assoc()['total'] ?? 0;
    
    // Pending orders
    $result = $conn->query("SELECT COUNT(*) as total FROM orders WHERE status = 'pending'");
    $pending_orders = $result->fetch_assoc()['total'];
    
    // Total customers
    $result = $conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'customer'");
    $total_customers = $result->fetch_assoc()['total'];
    
    echo json_encode([
        'success' => true,
        'data' => [
            'total_orders' => $total_orders,
            'total_revenue' => $total_revenue,
            'pending_orders' => $pending_orders,
            'total_customers' => $total_customers
        ]
    ]);
}
