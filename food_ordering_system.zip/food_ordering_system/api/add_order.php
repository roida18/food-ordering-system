<?php
require_once '../config/db.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!is_logged_in()) {
    echo json_encode(['success' => false, 'message' => 'Please login to place order']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $cart_items = $data['cart_items'] ?? [];
    $payment_method = sanitize_input($data['payment_method'] ?? 'cash_on_delivery');
    $delivery_address = sanitize_input($data['delivery_address'] ?? '');
    
    if (empty($cart_items)) {
        echo json_encode(['success' => false, 'message' => 'Cart is empty']);
        exit();
    }

    // Calculate total
    $total_amount = 0;
    foreach ($cart_items as $item) {
        $total_amount += $item['price'] * $item['quantity'];
    }

    // Start transaction
    $conn->begin_transaction();

    try {
        // Insert order
        $user_id = $_SESSION['user_id'];
        $stmt = $conn->prepare("INSERT INTO orders (user_id, total_amount, status, delivery_address) VALUES (?, ?, 'pending', ?)");
        $stmt->bind_param("ids", $user_id, $total_amount, $delivery_address);
        $stmt->execute();
        
        $order_id = $conn->insert_id;

        // Insert order details
        foreach ($cart_items as $item) {
            $food_id = $item['food_id'];
            $quantity = $item['quantity'];
            $price = $item['price'];
            
            $stmt = $conn->prepare("INSERT INTO order_details (order_id, food_id, quantity, price) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("iiid", $order_id, $food_id, $quantity, $price);
            $stmt->execute();
        }

        // Insert payment
        $payment_status = ($payment_method === 'cash_on_delivery') ? 'pending' : 'completed';
        $stmt = $conn->prepare("INSERT INTO payments (order_id, payment_method, payment_status, amount) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("issd", $order_id, $payment_method, $payment_status, $total_amount);
        $stmt->execute();

        // Commit transaction
        $conn->commit();

        echo json_encode(['success' => true, 'message' => 'Order placed successfully!', 'order_id' => $order_id]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => 'Order failed: ' . $e->getMessage()]);
    }
}
