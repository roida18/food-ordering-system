-- Food Ordering System Database Setup
-- Run this script in MySQL (via phpMyAdmin or MySQL Command Line)

-- Create Database
CREATE DATABASE IF NOT EXISTS food_ordering_system;
USE food_ordering_system;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    role ENUM('admin', 'customer') DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Food Items Table
CREATE TABLE IF NOT EXISTS food_items (
    food_id INT AUTO_INCREMENT PRIMARY KEY,
    food_name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    category VARCHAR(50) DEFAULT 'burger',
    availability TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Orders Table
CREATE TABLE IF NOT EXISTS orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    total_amount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'processing', 'completed', 'cancelled') DEFAULT 'pending',
    delivery_address TEXT,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Order Details Table
CREATE TABLE IF NOT EXISTS order_details (
    order_detail_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    food_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (food_id) REFERENCES food_items(food_id) ON DELETE CASCADE
);

-- Payments Table
CREATE TABLE IF NOT EXISTS payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    payment_method VARCHAR(50) DEFAULT 'cash_on_delivery',
    payment_status ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
    amount DECIMAL(10, 2) NOT NULL,
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
); 
--categories Table
CREATE TABLE IF NOT EXISTS CATEGORIES(
    category id INT OUTO INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL
);

-- Insert Admin User (Password: admin123)
INSERT INTO users (name, email, password, phone, address, role) VALUES 
('Admin User', 'admin@foodiehub.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '1234567890', '123 Admin Street, Food City', 'admin');

-- Insert Sample Food Items
INSERT INTO food_items (food_name, description, price, category) VALUES
-- Burgers
('Classic Burger', 'Juicy beef patty with lettuce, tomato, onion, and our special sauce', 8.99, 'burger'),
('Cheese Burger', 'Classic burger with melted cheddar cheese', 9.99, 'burger'),
('Bacon Burger', 'Beef patty with crispy bacon and cheese', 11.99, 'burger'),
('Veggie Burger', 'Plant-based patty with fresh vegetables', 7.99, 'burger'),
('Double Burger', 'Two beef patties with double cheese', 13.99, 'burger'),

-- Pizza
('Margherita Pizza', 'Classic tomato sauce, mozzarella, and fresh basil', 12.99, 'pizza'),
('Pepperoni Pizza', 'Pepperoni with mozzarella cheese', 14.99, 'pizza'),
('Veggie Pizza', 'Mixed vegetables with mozzarella', 11.99, 'pizza'),
('BBQ Chicken Pizza', 'Grilled chicken with BBQ sauce', 15.99, 'pizza'),
('Hawaiian Pizza', 'Ham and pineapple with cheese', 13.99, 'pizza'),

-- Asian
('Chicken Fried Rice', 'Stir-fried rice with chicken and vegetables', 9.99, 'asian'),
('Pad Thai', 'Rice noodles with shrimp, peanuts, and special sauce', 11.99, 'asian'),
('Spring Rolls', 'Crispy rolls with vegetable filling', 5.99, 'asian'),
('Hot & Sour Soup', 'Traditional soup with mushrooms and tofu', 6.99, 'asian'),
('Kung Pao Chicken', 'Spicy chicken with peanuts and vegetables', 12.99, 'asian'),

-- Drinks
('Cola', 'Refreshing cola drink', 1.99, 'drink'),
('Lemonade', 'Freshly squeezed lemon drink', 2.49, 'drink'),
('Iced Tea', 'Cold iced tea with lemon', 2.99, 'drink'),
('Mango Smoothie', 'Fresh mango blended with ice', 4.99, 'drink'),
('Coffee', 'Hot brewed coffee', 2.99, 'drink'),

-- Desserts
('Chocolate Cake', 'Rich chocolate layer cake', 5.99, 'dessert'),
('Ice Cream', 'Three scoops of vanilla ice cream', 4.99, 'dessert'),
('Apple Pie', 'Warm apple pie with cinnamon', 4.99, 'dessert'),
('Brownie', 'Fudge brownie with chocolate sauce', 3.99, 'dessert'),
('Cheesecake', 'Creamy cheesecake with berry topping', 6.99, 'dessert');

-- Sample Customer User (Password: user123)
INSERT INTO users (name, email, password, phone, address, role) VALUES 
('John Doe', 'john@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9876543210', '456 Customer Avenue, Food City', 'customer');
  
-- Create Indexes for Better Performance
CREATE INDEX idx_orders_user_id ON orders(user_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_order_details_order_id ON order_details(order_id);
CREATE INDEX idx_food_items_category ON food_items(category);

-- Display success message
SELECT 'Database setup completed successfully!' AS message;
SELECT 'Admin Login: admin@foodiehub.com / admin123' AS admin_login;
SELECT 'Customer Login: john@example.com / user123' AS customer_login;
