<?php
// Database credentials
$servername = "localhost";
$username = "root";
$password = ""; // empty because we have no root password
$database = "food_ordering_system"; // replace with your DB name
$port = 3306; // your MySQL port
// Create connection
$conn = new mysqli($servername, $username, $password, $database, $port);
// Check connection
if ($conn->connect_error) {
 die(" Connection failed: " . $conn->connect_error);
}
?>
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="FoodieHub - Order delicious food online from the best restaurants">
    <title>RD Food supplier - Food Delivery</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="navbar-inner">
            <a href="index.html" class="nav-brand">RD Food SupplierHub</a>
            
            <div class="nav-center">
                <a href="index.html" class="nav-link active">Home</a>
                <a href="menu.php" class="nav-link">Menu</a>
                <a href="about.html" class="nav-link">About</a>
                <a href="contact.html" class="nav-link">Contact</a>
            </div>
            
            <div class="nav-right">
                <div class="search-container">
                    <svg class="search-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="11" cy="11" r="8"></circle>
                        <path d="m21 21-4.35-4.35"></path>
                    </svg>
                    <input type="text" class="search-input" placeholder="Search restaurants, dishes...">
                </div>
                
                <?php if (isset($_SESSION['name'])): ?>
                    <div class="user-menu">
                          <div class="user-avatar"><?php echo substr($_SESSION['name'], 0, 2); ?></div>
        <span class="user-name"><?php echo htmlspecialchars($_SESSION['name']); ?></span>
    </div>
                    <button class="cart-button" onclick="toggleCart()">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="9" cy="21" r="1"></circle>
                            <circle cx="20" cy="21" r="1"></circle>
                            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                        </svg>
                        <span class="cart-badge">0</span>
                    </button>
                <?php else: ?>
                    <a href="auth/login.php" class="btn btn-ghost hide-mobile">Log in</a>
                    <a href="auth/register.php" class="btn btn-primary">Sign up</a>
                    <button class="cart-button" onclick="toggleCart()">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="9" cy="21" r="1"></circle>
                            <circle cx="20" cy="21" r="1"></circle>
                            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                        </svg>
                    </button>
                <?php endif; ?>
                
                <button class="mobile-menu-toggle hide-desktop">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="3" y1="12" x2="21" y2="12"></line>
                        <line x1="3" y1="6" x2="21" y2="6"></line>
                        <line x1="3" y1="18" x2="21" y2="18"></line>
                    </svg>
                </button>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-bg">
            <div class="hero-bg-shape hero-bg-shape-1"></div>
            <div class="hero-bg-shape hero-bg-shape-2"></div>
        </div>
        
        <div class="hero-content">
            <div class="hero-badge">
                <span>🚀</span>
                <span>Free delivery on your first order!</span>
            </div>
            <h1>Delicious food, delivered to your door</h1>
            <p class="hero-description">Order from the best local restaurants with just a few clicks. Fresh, hot meals delivered to your doorstep.</p>
            
            <div class="hero-actions">
                <a href="menu.php" class="btn btn-primary btn-lg">Order Now</a>
                <a href="menu.php" class="btn btn-secondary btn-lg">View Menu</a>
            </div>
        </div>
    </section>

    <!-- Search Section -->
    <section class="search-section">
        <div class="container">
            <div class="search-card">
                <div class="search-row">
                    <div class="search-field">
                        <label>Location</label>
                        <input type="text" placeholder="Enter your address">
                    </div>
                    <div class="search-field">
                        <label>Cuisine</label>
                        <select>
                            <option value="">All cuisines</option>
                            <option value="burger">Burgers</option>
                            <option value="pizza">Pizza</option>
                            <option value="asian">Asian</option>
                            <option value="drink">Drinks</option>
                        </select>
                    </div>
                    <div class="search-field" style="flex: 0 0 auto;">
                        <label>&nbsp;</label>
                        <a href="menu.php" class="btn btn-primary" style="width: 100%;">Search</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Categories Section -->
    <section class="categories-section">
        <div class="container">
            <div class="section-header">
                <div class="section-title">
                    <span>Categories</span>
                    <h2>Browse by cuisine</h2>
                </div>
                <a href="menu.php" class="btn btn-ghost">View all →</a>
            </div>
            
            <div class="categories-grid">
                <a href="menu.php?category=burger" class="category-card">
                    <span class="category-icon">🍔</span>
                    <span class="category-name">Burgers</span>
                </a>
                <a href="menu.php?category=pizza" class="category-card">
                    <span class="category-icon">🍕</span>
                    <span class="category-name">Pizza</span>
                </a>
                <a href="menu.php?category=asian" class="category-card">
                    <span class="category-icon">🍜</span>
                    <span class="category-name">Asian</span>
                </a>
                <a href="menu.php?category=drink" class="category-card">
                    <span class="category-icon">🥤</span>
                    <span class="category-name">Drinks</span>
                </a>
                <a href="menu.php?category=dessert" class="category-card">
                    <span class="category-icon">🍰</span>
                    <span class="category-name">Desserts</span>
                </a>
                <a href="menu.php" class="category-card">
                    <span class="category-icon">✨</span>
                    <span class="category-name">All</span>
                </a>
            </div>
        </div>
    </section>

    <!-- How It Works -->
    <section class="features" style="background: var(--white); padding: 5rem 0;">
        <div class="container">
            <div class="section-header" style="justify-content: center; margin-bottom: 3rem;">
                <div class="section-title" style="text-align: center;">
                    <span>How it works</span>
                    <h2>Ordering is easy</h2>
                </div>
            </div>
            
            <div class="steps" style="justify-content: center; gap: 4rem;">
                <div class="step" style="text-align: center; max-width: 280px;">
                    <div class="step-number" style="width: 64px; height: 64px; font-size: 1.5rem; margin: 0 auto 1.5rem;">1</div>
                    <h3 style="margin-bottom: 0.5rem;">Choose your food</h3>
                    <p style="color: var(--text-muted);">Browse menus from local restaurants and pick your favorites</p>
                </div>
                <div class="step" style="text-align: center; max-width: 280px;">
                    <div class="step-number" style="width: 64px; height: 64px; font-size: 1.5rem; margin: 0 auto 1.5rem;">2</div>
                    <h3 style="margin-bottom: 0.5rem;">Place your order</h3>
                    <p style="color: var(--text-muted);">Add items to cart and checkout with cash or card</p>
                </div>
                <div class="step" style="text-align: center; max-width: 280px;">
                    <div class="step-number" style="width: 64px; height: 64px; font-size: 1.5rem; margin: 0 auto 1.5rem;">3</div>
                    <h3 style="margin-bottom: 0.5rem;">Enjoy your meal</h3>
                    <p style="color: var(--text-muted);">Receive fresh food at your doorstep in minutes</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Popular Dishes -->
    <section class="menu-section" style="background: var(--gray-50);">
        <div class="container">
            <div class="menu-header">
                <div class="section-title">
                    <span>Popular</span>
                    <h2>Trending near you</h2>
                </div>
                <div class="menu-tabs">
                    <button class="menu-tab active">All</button>
                    <button class="menu-tab">Burgers</button>
                    <button class="menu-tab">Pizza</button>
                    <button class="menu-tab">Asian</button>
                </div>
            </div>
            
            <div class="menu-grid" id="popular-dishes">
                <!-- Will be loaded via JavaScript -->
            </div>
            
            <div style="text-align: center; margin-top: 2rem;">
                <a href="menu.php" class="btn btn-secondary">View Full Menu</a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <h3>RD Food Supplier</h3>
                    <p>Delicious food delivered fast. The best local restaurants at your fingertips.</p>
                </div>
                <div>
                    <h4 class="footer-title">Company</h4>
                    <div class="footer-links">
                        <a href="about.html">About Us</a>
                        <a href="gallery.html">Gallery</a>
                        <a href="#">Press</a>
                        <a href="#">Blog</a>
                    </div>
                </div>
                <div>
                    <h4 class="footer-title">Support</h4>
                    <div class="footer-links">
                        <a href="faq.html">Help Center</a>
                        <a href="contact.html">Contact Us</a>
                        <a href="faq.html">FAQs</a>
                        <a href="terms.html">Terms of Service</a>
                    </div>
                </div>
                <div>
                    <h4 class="footer-title">Contact</h4>
                    <div class="footer-links">
                        <a href="#">📍 dar es salaam ,Tanzania</a>
                        <a href="#">📞 0752 509 256</a>
                        <a href="#">✉️ roidamlula6@gmail.com</a>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 RD food ordering. All rights reserved.</p>
                <div class="footer-social">
                    <a href="#" aria-label="Facebook">📘</a>
                    <a href="#" aria-label="Twitter">🐦</a>
                    <a href="#" aria-label="Instagram">📷</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Cart Sidebar -->
    <div class="cart-overlay" onclick="toggleCart()"></div>
    <div class="cart-sidebar">
        <div class="cart-header">
            <h2>Your cart</h2>
            <button class="cart-close" onclick="toggleCart()">×</button>
        </div>
        <div class="cart-items" id="cart-items">
            <!-- Cart items will be loaded here -->
        </div>
        <div class="cart-footer">
            <div class="cart-summary">
                <div class="cart-summary-row">
                    <span>Subtotal</span>
                    <span id="cart-subtotal">$0.00</span>
                </div>
                <div class="cart-summary-row">
                    <span>Delivery fee</span>
                    <span>$2.00</span>
                </div>
                <div class="cart-summary-row total">
                    <span>Total</span>
                    <span id="cart-total">$2.00</span>
                 </div>
            </div>
            <?php if (isset($_SESSION['name'])): ?>
                <a href="checkout.html" class="btn btn-primary btn-block">Checkout</a>
                <php else: ?>
                <a href="auth/login.php" class="btn btn-primary btn-block">Login to order</a>
                <?php endif; ?>
        </div>
    </div>

    <script src="js/main.js"></script>
    <script>
        // Load popular dishes on page load
        document.addEventListener('DOMContentLoaded', async function() {
            try {
                const response = await fetch('api/get_menu.php');
                const data = await response.json();
                
                if (data.success) {
                    const popularItems = data.data.slice(0, 6);
                    renderPopularDishes(popularItems);
                }
            } catch (error) {
                console.error('Error loading dishes:', error);
            }
        });

        function renderPopularDishes(items) {
            const container = document.getElementById('popular-dishes');
            if (!container) return;

            container.innerHTML = items.map(item => `
                <div class="menu-card">
                    <div class="menu-card-image">
                        <span style="font-size: 4rem;">${getFoodEmoji(item.category)}</span>
                    </div>
                    <button class="menu-card-favorite" onclick="toggleFavorite(${item.food_id})">♡</button>
                    <div class="menu-card-content">
                        <div class="menu-card-header">
                            <h3 class="menu-card-title">${item.food_name}</h3>
                            <div class="menu-card-rating">
                                <svg viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                                <span>4.8</span>
                            </div>
                        </div>
                        <p class="menu-card-description">${item.description}</p>
                        <div class="menu-card-footer">
                            <div class="menu-card-price">
                                <span class="price">$${parseFloat(item.price).toFixed(2)}</span>
                                <span class="delivery">15-25 min</span>
                            </div>
                            <button class="add-button" onclick="addToCart(${item.food_id}, '${item.food_name}', ${item.price})">
                                <span>+</span> Add
                            </button>
                        </div>
                    </div>
                </div>
            `).join('');
        }

        function getFoodEmoji(category) {
            const emojis = {
                'burger': '🍔',
                'pizza': '🍕',
                'asian': '🍜',
                'drink': '🥤',
                'dessert': '🍰'
            };
            return emojis[category] || '🍽️';
        }

        function toggleFavorite(foodId) {
            showToast('Added to favorites!', 'success');
        }
    </script>
</body>
</html>