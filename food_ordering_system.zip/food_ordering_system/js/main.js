/**
 * FoodieHub - Modern Food Ordering System
 * Main JavaScript File
 */

// ============================================
// Cart Management
// ============================================

// Global cart state
let cart = JSON.parse(localStorage.getItem('foodiehub_cart')) || [];

// Save cart to localStorage
function saveCart() {
    localStorage.setItem('foodiehub_cart', JSON.stringify(cart));
    updateCartDisplay();
}

// Add item to cart with animation
function addToCart(foodId, foodName, price) {
    const existingItem = cart.find(item => item.food_id === foodId);

    if (existingItem) {
        existingItem.quantity += 1;
        showToast(`${foodName} quantity increased!`, 'success');
    } else {
        cart.push({
            food_id: foodId,
            food_name: foodName,
            price: parseFloat(price),
            quantity: 1
        });
        showToast(`${foodName} added to cart!`, 'success');
    }

    saveCart();
    animateCartIcon();
}

// Remove item from cart
function removeFromCart(foodId) {
    const item = cart.find(i => i.food_id === foodId);
    if (item) {
        showToast(`${item.food_name} removed from cart`, 'info');
    }
    cart = cart.filter(item => item.food_id !== foodId);
    saveCart();
}

// Update item quantity
function updateQuantity(foodId, change) {
    const item = cart.find(item => item.food_id === foodId);

    if (item) {
        item.quantity += change;

        if (item.quantity <= 0) {
            removeFromCart(foodId);
        } else {
            saveCart();
        }
    }
}

// Get cart total
function getCartTotal() {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
}

// Get cart item count
function getCartCount() {
    return cart.reduce((count, item) => count + item.quantity, 0);
}

// Update cart display
function updateCartDisplay() {
    const cartCountElements = document.querySelectorAll('#cart-count, #cart-toggle-count');
    cartCountElements.forEach(el => {
        if (el) {
            const count = getCartCount();
            el.textContent = count;
            el.style.display = count > 0 ? 'flex' : 'none';
        }
    });

    // Update cart sidebar
    const cartItemsContainer = document.getElementById('cart-items');
    if (cartItemsContainer) {
        renderCartSidebar();
    }
}

// Animate cart icon
function animateCartIcon() {
    const cartToggle = document.getElementById('cart-toggle');
    if (cartToggle) {
        cartToggle.style.transform = 'scale(1.2)';
        setTimeout(() => {
            cartToggle.style.transform = 'scale(1)';
        }, 200);
    }
}

// ============================================
// Cart Sidebar
// ============================================

function toggleCart() {
    const cartSidebar = document.getElementById('cart-sidebar');
    const cartToggle = document.getElementById('cart-toggle');
    
    if (cartSidebar) {
        cartSidebar.classList.toggle('open');
        renderCartSidebar();
        
        // Toggle aria attribute for accessibility
        const isOpen = cartSidebar.classList.contains('open');
        cartSidebar.setAttribute('aria-hidden', !isOpen);
        document.body.style.overflow = isOpen ? 'hidden' : '';
    }
}

function renderCartSidebar() {
    const cartItemsContainer = document.getElementById('cart-items');
    const emptyMessage = document.querySelector('#cart-items p');

    if (!cartItemsContainer) return;

    if (cart.length === 0) {
        cartItemsContainer.innerHTML = `
            <div class="empty-cart-message" style="text-align: center; padding: 3rem 1rem;">
                <div style="font-size: 4rem; margin-bottom: 1rem;">🛒</div>
                <h3 style="color: var(--text-secondary); margin-bottom: 0.5rem;">Your cart is empty</h3>
                <p style="color: var(--text-muted);">Add delicious items to get started!</p>
            </div>
        `;
        return;
    }

    cartItemsContainer.innerHTML = cart.map(item => `
        <div class="cart-item" data-food-id="${item.food_id}">
            <div class="cart-item-image">${getFoodEmoji(item.category || 'burger')}</div>
            <div class="cart-item-info">
                <h4>${escapeHtml(item.food_name)}</h4>
                <span class="price">$${item.price.toFixed(2)}</span>
            </div>
            <div class="cart-item-actions">
                <div class="quantity-controls">
                    <button class="quantity-btn" onclick="updateQuantity(${item.food_id}, -1)" aria-label="Decrease quantity">−</button>
                    <span class="quantity">${item.quantity}</span>
                    <button class="quantity-btn" onclick="updateQuantity(${item.food_id}, 1)" aria-label="Increase quantity">+</button>
                </div>
                <button class="remove-item" onclick="removeFromCart(${item.food_id})" aria-label="Remove item">🗑️</button>
            </div>
        </div>
    `).join('');

    // Update total
    const totalElement = document.getElementById('cart-total-amount');
    if (totalElement) {
        totalElement.textContent = '$' + getCartTotal().toFixed(2);
    }
}

// ============================================
// Menu Functions
// ============================================

let allMenuItems = [];

async function loadMenu() {
    try {
        showLoading(true);
        const response = await fetch('api/get_menu.php');
        const data = await response.json();

        if (data.success) {
            allMenuItems = data.data;
            renderMenu(data.data);
        } else {
            showToast('Failed to load menu', 'error');
        }
    } catch (error) {
        console.error('Error loading menu:', error);
        showToast('Error loading menu. Please try again.', 'error');
    } finally {
        showLoading(false);
    }
}

function renderMenu(items) {
    const menuContainer = document.getElementById('menu-container');

    if (!menuContainer) return;

    if (items.length === 0) {
        menuContainer.innerHTML = `
            <div class="empty-menu" style="grid-column: 1 / -1; text-align: center; padding: 4rem;">
                <div style="font-size: 4rem;">🍽️</div>
                <h3 style="color: var(--text-secondary); margin: 1rem 0 0.5rem;">No items available</h3>
                <p style="color: var(--text-muted);">Check back later for delicious offerings!</p>
            </div>
        `;
        return;
    }

    menuContainer.innerHTML = items.map(item => `
        <div class="menu-item" data-category="${item.category}" data-food-id="${item.food_id}">
            <div class="menu-item-image">${getFoodEmoji(item.category)}</div>
            <div class="menu-item-info">
                <h3>${escapeHtml(item.food_name)}</h3>
                <p>${escapeHtml(item.description)}</p>
                <div class="menu-item-footer">
                    <span class="price">$${parseFloat(item.price).toFixed(2)}</span>
                    <button class="add-to-cart-btn" onclick="addToCart(${item.food_id}, '${escapeHtml(item.food_name)}', ${item.price})">
                        <span>+</span> Add to Cart
                    </button>
                </div>
            </div>
        </div>
    `).join('');

    // Setup category filters
    setupMenuFilters();
}

function setupMenuFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');

    filterButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            // Update active button
            filterButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            // Filter menu items
            const category = btn.dataset.category;
            const menuItems = document.querySelectorAll('.menu-item');

            menuItems.forEach(item => {
                if (category === 'all' || item.dataset.category === category) {
                    item.style.display = 'block';
                    item.style.animation = 'fadeInUp 0.5s ease forwards';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });
}

function getFoodEmoji(category) {
    const emojis = {
        'burger': '🍔',
        'pizza': '🍕',
        'asian': '🍜',
        'drink': '🥤',
        'dessert': '🍰'
    };
    return emojis[category] || '🍽️';
}

// ============================================
// Cart Page
// ============================================

function displayCartPage() {
    const cartContent = document.getElementById('cart-content');
    const cartEmpty = document.getElementById('cart-empty');
    const cartSummary = document.getElementById('cart-summary');

    if (!cartContent) return;

    if (cart.length === 0) {
        cartEmpty.style.display = 'block';
        cartSummary.style.display = 'none';
        cartContent.innerHTML = '';
        return;
    }

    cartEmpty.style.display = 'none';
    cartSummary.style.display = 'block';

    cartContent.innerHTML = cart.map(item => `
        <div class="cart-item-card" data-food-id="${item.food_id}">
            <div class="cart-item-card-image">${getFoodEmoji(item.category || 'burger')}</div>
            <div class="cart-item-card-info">
                <h3>${escapeHtml(item.food_name)}</h3>
                <span class="price">$${item.price.toFixed(2)}</span>
                <div class="cart-item-card-actions">
                    <div class="quantity-controls">
                        <button class="quantity-btn" onclick="updateQuantity(${item.food_id}, -1)">−</button>
                        <span class="quantity">${item.quantity}</span>
                        <button class="quantity-btn" onclick="updateQuantity(${item.food_id}, 1)">+</button>
                    </div>
                    <button class="btn btn-outline btn-sm" onclick="removeFromCart(${item.food_id})">Remove</button>
                </div>
            </div>
        </div>
    `).join('');

    // Update totals
    const subtotal = getCartTotal();
    const deliveryFee = 2.00;
    const total = subtotal + deliveryFee;

    document.getElementById('subtotal').textContent = '$' + subtotal.toFixed(2);
    document.getElementById('total').textContent = '$' + total.toFixed(2);
}

// ============================================
// Checkout Functions
// ============================================

function loadCheckout() {
    const checkoutItems = document.getElementById('checkout-items');

    if (!checkoutItems) return;

    if (cart.length === 0) {
        window.location.href = 'cart.html';
        return;
    }

    checkoutItems.innerHTML = cart.map(item => `
        <div class="checkout-item">
            <span>${escapeHtml(item.food_name)} × ${item.quantity}</span>
            <span>$${(item.price * item.quantity).toFixed(2)}</span>
        </div>
    `).join('');

    // Update totals
    const subtotal = getCartTotal();
    const deliveryFee = 2.00;
    const total = subtotal + deliveryFee;

    document.getElementById('checkout-subtotal').textContent = '$' + subtotal.toFixed(2);
    document.getElementById('checkout-total').textContent = '$' + total.toFixed(2);
}

async function placeOrder() {
    const deliveryAddress = document.getElementById('delivery_address').value.trim();

    if (!deliveryAddress) {
        showToast('Please enter your delivery address', 'error');
        document.getElementById('delivery_address').focus();
        return;
    }

    if (cart.length === 0) {
        showToast('Your cart is empty', 'error');
        return;
    }

    const paymentMethod = document.querySelector('input[name="payment_method"]:checked').value;

    try {
        showLoading(true);
        const response = await fetch('api/add_order.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                cart_items: cart,
                payment_method: paymentMethod,
                delivery_address: deliveryAddress
            })
        });

        const data = await response.json();

        if (data.success) {
            // Clear cart
            cart = [];
            saveCart();

            // Show success modal
            document.getElementById('order-id').textContent = '#' + data.order_id;
            document.getElementById('order-success-modal').classList.add('open');
            
            // Confetti effect (simple)
            createConfetti();
        } else {
            showToast(data.message || 'Failed to place order', 'error');
        }
    } catch (error) {
        console.error('Error placing order:', error);
        showToast('Error placing order. Please try again.', 'error');
    } finally {
        showLoading(false);
    }
}

// ============================================
// Toast Notifications
// ============================================

function showToast(message, type = 'success') {
    // Remove existing toasts
    const existingToast = document.querySelector('.toast-container');
    if (existingToast) {
        existingToast.remove();
    }

    // Create toast container
    const container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);

    // Create toast element
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    const icons = {
        success: '✓',
        error: '✕',
        info: 'ℹ'
    };
    
    toast.innerHTML = `
        <span style="margin-right: 0.5rem;">${icons[type]}</span>
        <span>${escapeHtml(message)}</span>
    `;

    container.appendChild(toast);

    // Remove after delay
    setTimeout(() => {
        toast.style.animation = 'slideOutRight 0.3s ease forwards';
        setTimeout(() => {
            toast.remove();
            if (container.children.length === 0) {
                container.remove();
            }
        }, 300);
    }, 3000);
}

// ============================================
// Loading States
// ============================================

function showLoading(show) {
    let loader = document.querySelector('.loading-overlay');
    
    if (show) {
        if (!loader) {
            loader = document.createElement('div');
            loader.className = 'loading-overlay';
            loader.innerHTML = '<div class="loading-spinner"></div>';
            document.body.appendChild(loader);
        }
        loader.style.display = 'flex';
    } else {
        if (loader) {
            loader.style.display = 'none';
        }
    }
}

// ============================================
// Confetti Effect
// ============================================

function createConfetti() {
    const colors = ['#ff6b35', '#27ae60', '#3498db', '#f39c12', '#9b59b6'];
    
    for (let i = 0; i < 50; i++) {
        const confetti = document.createElement('div');
        confetti.style.cssText = `
            position: fixed;
            width: 10px;
            height: 10px;
            background: ${colors[Math.floor(Math.random() * colors.length)]};
            left: ${Math.random() * 100}vw;
            top: -10px;
            border-radius: ${Math.random() > 0.5 ? '50%' : '0'};
            pointer-events: none;
            z-index: 9999;
            animation: confettiFall ${2 + Math.random() * 2}s linear forwards;
        `;
        document.body.appendChild(confetti);

        setTimeout(() => confetti.remove(), 4000);
    }
}

// Add confetti animation
const confettiStyle = document.createElement('style');
confettiStyle.textContent = `
    @keyframes confettiFall {
        to {
            transform: translateY(100vh) rotate(720deg);
            opacity: 0;
        }
    }
`;
document.head.appendChild(confettiStyle);

// ============================================
// Utility Functions
// ============================================

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function capitalizeFirst(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

function formatCurrency(amount) {
    return '$' + parseFloat(amount).toFixed(2);
}

// ============================================
// Modal Functions
// ============================================

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('open');
        document.body.style.overflow = '';
    }
}

// Close modal on outside click
document.addEventListener('click', function(event) {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        if (event.target === modal) {
            modal.classList.remove('open');
            document.body.style.overflow = '';
        }
    });
});

// Close modal on escape key
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        const openModals = document.querySelectorAll('.modal.open');
        openModals.forEach(modal => {
            modal.classList.remove('open');
        });
        document.body.style.overflow = '';
        
        const cartSidebar = document.getElementById('cart-sidebar');
        if (cartSidebar && cartSidebar.classList.contains('open')) {
            cartSidebar.classList.remove('open');
        }
    }
});

// ============================================
// Navbar Scroll Effect
// ============================================

function handleNavbarScroll() {
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    }
}

// ============================================
// Initialize on Page Load
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    // Update cart display
    updateCartDisplay();

    // Add scroll listener for navbar
    window.addEventListener('scroll', handleNavbarScroll);

    // Add fade-in animation to sections
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, { threshold: 0.1 });

    document.querySelectorAll('.feature-card, .category-card, .step, .menu-item').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
});

// Export functions for global use
window.addToCart = addToCart;
window.removeFromCart = removeFromCart;
window.updateQuantity = updateQuantity;
window.toggleCart = toggleCart;
window.placeOrder = placeOrder;
window.closeModal = closeModal;
window.showToast = showToast;
