<?php
require_once '../config/db.php';

// Destroy session
session_destroy();
redirect('../login.php');
